#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Rotation circulaire a gauche
uint8_t rotl(uint8_t x)
{
    return (uint8_t)((x << 3) | (x >> 5));
}

// Rotation circulaire a droite
uint8_t rotr(uint8_t x)
{
    return (uint8_t)((x >> 3) | (x << 5));
}

// Fonction de chiffrement
uint8_t chiffrer(uint8_t M, uint8_t K1, uint8_t K2)
{
    uint8_t etape1 = M ^ K1;

    uint8_t etape2 = rotl(etape1);

    uint8_t etape3 = etape2 ^ K2;

    return etape3;
}

// Fonction de dechiffrement
uint8_t dechiffrer(uint8_t C, uint8_t K1, uint8_t K2)
{
    uint8_t etape1 = C ^ K2;

    uint8_t etape2 = rotr(etape1);

    uint8_t etape3 = etape2 ^ K1;

    return etape3;
}

int main()
{
    char message[100] ;
    char resultat[100];

    uint8_t chiffre[100];

    unsigned int choix_K1, choix_K2;

    uint8_t K1, K2;

    // Saisie du message
    printf("Entrez un message : ");
    fgets(message, sizeof(message), stdin);

    // Suppression du retour a la ligne
    message[strcspn(message, "\n")] = '\0';

    // Saisie des cles
    printf("Entrez la premiere cle (0-255) : ");
    if (scanf("%u", &choix_K1) != 1 || choix_K1 > 255)
    {
        printf("Premiere cle invalide !\n");
        return 1;
    }

    printf("Entrez la deuxieme cle (0-255) : ");
    if (scanf("%u", &choix_K2) != 1 || choix_K2 > 255)
    {
        printf("Deuxieme cle invalide !\n");
        return 1;
    }

    K1 = (uint8_t)choix_K1;
    K2 = (uint8_t)choix_K2;

    int taille = strlen(message);

    // CHIFFREMENT
    for (int i = 0; i < taille; i++)
    {
        chiffre[i] = chiffrer((uint8_t)message[i], K1, K2);
    }

    // Affichage du message chiffre
    printf("\nMessage chiffre :\n");

    for (int i = 0; i < taille; i++)
    {
        printf("%u ", chiffre[i]);
    }

    // DECHIFFREMENT
    for (int i = 0; i < taille; i++)
    {
        resultat[i] = (char)dechiffrer(chiffre[i], K1, K2);
    }

    resultat[taille] = '\0';

    // Affichage du message dechiffre
    printf("\n\nMessage dechiffre :\n");
    printf("%s\n", resultat);

    return 0;
}
